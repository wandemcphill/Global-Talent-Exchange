# GTEX Schema Pack

This ZIP contains the schema companion for the GTEX master Codex prompt.

Feed this alongside the master prompt if you want Codex to:
- move faster
- keep table design sane
- avoid wallet/economy confusion
- preserve a rules-driven architecture

Primary file:
- GTEX_DATABASE_SCHEMA_AND_ARCHITECTURE.md