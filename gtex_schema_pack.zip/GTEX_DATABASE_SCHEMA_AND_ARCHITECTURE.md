# GTEX DATABASE + SCHEMA + CORE TABLE DESIGN PACK
Version: Schema companion for GTEX master Codex prompt

This document is a schema/design companion to accelerate Codex implementation.

## Goals
Define a clean database and domain model for:
- rules-driven competition engine
- event-driven services
- wallet and ledger system
- FanCoin and Coin economy
- player cards marketplace
- stadium and club infrastructure
- spectator/gifting economy
- national team tournaments
- compliance/legal docs
- admin autopilot orchestration
- analytics and integrity engine

Use this as a guide, not a prison. Codex may refine names/types to fit the existing codebase, but the domain boundaries must remain intact.

---

# 1. CORE DOMAIN GROUPS

## A. Identity and accounts
- users
- user_profiles
- user_devices
- user_region_history
- user_document_acceptances
- user_risk_flags

## B. Clubs and teams
- clubs
- club_identities
- club_reputation_history
- club_level_history
- club_points_history
- club_prestige_history
- club_followers
- club_supporter_tokens
- club_rivalries
- club_stadiums
- club_facilities
- club_trophy_cabinets
- club_story_feed_items

## C. Player master data
- players
- player_aliases
- player_monikers
- player_import_jobs
- player_import_items
- player_youth_pool
- player_stats_snapshots
- player_market_value_snapshots

## D. Player cards
- player_cards
- player_card_tiers
- player_card_supply_batches
- player_card_histories
- player_card_owner_history
- player_card_effects
- player_card_form_buffs
- player_card_momentum
- player_card_listings
- player_card_sales
- player_card_bids (optional)
- player_card_watchlists

## E. Competition engine
- competition_templates
- competitions
- competition_participants
- competition_rounds
- competition_matches
- competition_match_events
- competition_rewards
- competition_reward_pools
- competition_seed_rules
- competition_visibility_rules
- competition_entries
- competition_invites
- competition_playoffs
- competition_autofill_rules
- competition_schedule_jobs

## F. National team engine
- national_team_competitions
- national_team_entries
- national_team_squads
- national_team_loans
- national_team_awards
- national_team_rankings
- national_team_user_histories

## G. Wallet/economy
- wallets
- wallet_balances
- wallet_ledger_entries
- fancoin_purchase_orders
- market_topups
- withdrawals
- withdrawal_reviews
- economy_burn_events
- revenue_share_rules
- reward_settlements
- gift_transactions
- gift_catalog
- gift_combo_events
- service_pricing_rules

## H. Spectator/media
- match_views
- premium_video_purchases
- match_revenue_snapshots
- competition_watchlists
- live_threads
- private_messages
- public_feed_items
- comments
- reports
- moderation_actions

## I. Policy/compliance/admin
- country_feature_policies
- policy_documents
- policy_document_versions
- policy_acceptance_records
- admin_feature_flags
- admin_competition_templates
- admin_reward_rules
- admin_calendar_rules
- aml_cases
- fraud_cases
- integrity_scores
- system_events
- audit_logs

## J. Analytics / integrity
- metrics_daily
- metrics_hourly
- suspicious_gift_clusters
- suspicious_view_clusters
- suspicious_trade_clusters
- suspicious_match_clusters
- trust_tiers
- integrity_incidents

---

# 2. KEY TABLE DESIGNS

## users
- id
- email
- username
- password_hash / auth provider fields
- country_code
- region_locked_until
- region_change_used (bool)
- created_at
- updated_at
- status

## user_region_history
- id
- user_id
- old_country_code
- new_country_code
- changed_at
- actor_type
- permanent_change_applied
- note

## user_document_acceptances
- id
- user_id
- document_key
- document_version_id
- accepted_at
- ip_address
- device_id

---

## clubs
- id
- owner_user_id
- club_name
- display_slug
- city_name
- country_code
- identity_type
- stadium_id
- first_team_gsi
- academy_gsi
- club_points
- club_level
- club_reputation
- club_prestige
- fan_count
- media_value
- valuation_coin
- created_at
- updated_at
- status

## club_stadiums
- id
- club_id
- name
- level
- capacity
- theme_key
- gift_retention_bonus
- revenue_multiplier
- prestige_bonus
- created_at
- updated_at

## club_facilities
- id
- club_id
- training_level
- academy_level
- medical_level
- branding_level
- upkeep_cost_fancoin
- updated_at

## club_rivalries
- id
- club_a_id
- club_b_id
- rivalry_score
- label
- created_at
- updated_at

---

## players
- id
- external_source_id
- full_name
- common_name
- nationality_code
- birth_date
- primary_position
- secondary_positions
- current_real_world_club
- age
- is_youth
- created_at
- updated_at

## player_monikers
- id
- player_id
- card_scope
- moniker_text
- is_unique
- rarity_scope
- effect_key
- active

## player_import_jobs
- id
- source_type
- file_name / api_source
- status
- created_by
- created_at
- completed_at

## player_import_items
- id
- import_job_id
- raw_payload
- resolved_player_id
- status
- duplicate_confidence
- note

---

## player_cards
- id
- player_id
- season_edition
- tier
- serial_number
- base_value_coin
- effective_value_coin
- base_rating
- effective_rating
- xp
- level
- chemistry_tags
- owner_user_id
- owning_club_id
- is_listed
- status
- created_at
- updated_at

## player_card_supply_batches
- id
- player_id
- season_edition
- tier
- total_supply
- minted_count
- source_reason
- created_at

## player_card_histories
- id
- player_card_id
- event_type
- competition_id
- competition_name
- note
- created_at

## player_card_owner_history
- id
- player_card_id
- old_owner_user_id
- new_owner_user_id
- transferred_at
- transfer_type
- sale_price_coin

## player_card_form_buffs
- id
- player_card_id
- buff_type
- delta_rating
- starts_at
- ends_at
- source_reason

## player_card_listings
- id
- player_card_id
- seller_user_id
- listed_price_coin
- status
- created_at
- expires_at

## player_card_sales
- id
- player_card_id
- listing_id
- seller_user_id
- buyer_user_id
- gross_price_coin
- platform_fee_coin
- net_to_seller_coin
- sold_at

---

## competition_templates
- id
- key
- display_name
- competition_family
- team_type (club / national / youth_national)
- age_grade
- format_type (cup / league / playoff / fast_match)
- participant_min
- participant_max
- home_away_allowed
- penalties_allowed
- groups_allowed
- visibility_mode
- public_watch_allowed
- reward_source_type
- entry_currency_type
- entry_price_coin
- entry_price_fancoin
- gift_rule_type
- autoplay_enabled_default
- created_at
- updated_at

## competitions
- id
- template_id
- season_id
- region_key
- title
- state
- starts_at
- ends_at
- is_gtex_hosted
- is_national_team
- is_youth
- promo_pool_id
- admin_created
- autopilot_created
- created_at
- updated_at

## competition_participants
- id
- competition_id
- participant_type (club/user_national_entry)
- club_id
- user_id
- seed_rank
- joined_at
- status

## competition_rounds
- id
- competition_id
- round_name
- round_order
- stage_type
- starts_at
- ends_at
- state

## competition_matches
- id
- competition_id
- round_id
- home_participant_id
- away_participant_id
- kickoff_at
- match_state
- result_type
- home_score
- away_score
- penalties_home
- penalties_away
- match_hype_score
- 2d_view_open
- premium_video_open
- created_at
- updated_at

## competition_reward_pools
- id
- competition_id
- source_type (gtex_promotional_pool)
- currency_type
- total_budget
- distributed_amount
- remaining_amount
- admin_rule_version
- created_at
- updated_at

## competition_rewards
- id
- competition_id
- round_id
- reward_scope (match_result / stage_advance / final_position / special_award)
- outcome_key
- amount_coin
- amount_fancoin
- is_withdrawable
- source_pool_id
- active

## competition_autofill_rules
- id
- competition_id
- mode (invite / criteria / open / playoff_feed)
- criteria_json
- enabled
- created_at

## competition_schedule_jobs
- id
- template_id
- run_at
- status
- result_summary
- created_at

---

## national_team_entries
- id
- user_id
- country_code
- competition_id
- state
- represented_country_locked
- created_at

## national_team_squads
- id
- national_team_entry_id
- squad_size
- coach_source_type
- coach_ref_id
- created_at

## national_team_loans
- id
- national_team_entry_id
- player_id
- loan_card_shadow_id
- loan_cost_coin
- starts_at
- ends_at
- is_active
- marked_green

## national_team_awards
- id
- competition_id
- award_type
- winner_user_id
- winner_player_card_id
- loan_player_flag
- reward_coin
- created_at

---

## wallets
- id
- owner_type (user/club if needed)
- owner_id
- wallet_type (market_balance / restricted_rewards / fancoin / bonus)
- currency_type
- status
- created_at

## wallet_balances
- id
- wallet_id
- available_amount
- locked_amount
- updated_at

## wallet_ledger_entries
- id
- wallet_id
- source_tag
- amount
- direction (credit/debit)
- related_competition_id
- related_match_id
- related_gift_id
- related_card_sale_id
- related_withdrawal_id
- related_view_purchase_id
- is_withdrawable
- created_at
- metadata_json

## fancoin_purchase_orders
- id
- user_id
- payment_provider
- provider_reference
- gross_money_amount
- fancoin_credited
- status
- created_at

## market_topups
- id
- user_id
- payment_provider
- provider_reference
- money_amount
- coin_credited
- status
- created_at

## withdrawals
- id
- user_id
- wallet_id
- requested_amount_coin
- fee_amount_coin
- net_amount_coin
- status
- destination_type
- created_at
- reviewed_at

## gift_transactions
- id
- sender_user_id
- receiver_type (club/user)
- receiver_id
- competition_id
- match_id
- gift_catalog_id
- gross_fancoin
- platform_rake_fancoin
- net_fancoin
- settlement_type (withdrawable_market / nonwithdrawable_fancoin)
- created_at

## gift_catalog
- id
- key
- display_name
- tier
- fancoin_price
- animation_key
- sound_key
- active

## service_pricing_rules
- id
- service_key
- price_coin
- price_fancoin_equivalent
- active
- updated_at

## match_views
- id
- match_id
- viewer_user_id nullable
- anonymous_session_id nullable
- view_type (2d / premium_video)
- validity_score
- started_at
- ended_at
- country_code

## premium_video_purchases
- id
- match_id
- purchaser_user_id nullable
- session_id nullable
- paid_currency_type
- paid_amount
- settled_price_coin
- settled_price_fancoin
- created_at

## match_revenue_snapshots
- id
- match_id
- free_2d_views
- premium_video_views
- unique_gifters
- gift_value_fancoin
- gross_revenue_coin
- platform_share_coin
- home_share_coin
- away_share_coin
- underdog_bonus_coin
- created_at

---

## country_feature_policies
- id
- country_code
- bucket_type
- deposits_enabled
- market_trading_enabled
- platform_reward_withdrawals_enabled
- user_hosted_gift_withdrawals_enabled (should be false)
- gt_ex_competition_gift_withdrawals_enabled
- national_reward_withdrawals_enabled
- one_time_region_change_after_days
- active
- updated_at

## policy_documents
- id
- document_key
- title
- is_mandatory
- active

## policy_document_versions
- id
- policy_document_id
- version_label
- body_markdown
- effective_at
- published_at
- changelog

## policy_acceptance_records
- id
- user_id
- policy_document_version_id
- accepted_at
- ip_address

## integrity_scores
- id
- user_id
- score
- trust_tier
- updated_at

## suspicious_* tables
Track clusters/incidents for gifting, trades, views, matches.

---

# 3. RELATIONSHIP NOTES

- One user may own one or more clubs if product allows; if only one club per user, enforce unique constraint.
- One club has one stadium record and one facilities record.
- One player has many player cards across season editions and rarities.
- One player card has many history items and owner history items.
- One competition uses one template but many competitions may share a template.
- One competition has many rounds, matches, participants, rewards.
- One user can have multiple wallets by wallet_type, but only one active wallet per type.
- One gift transaction settles into either Market Balance or FanCoin based on competition context.
- One policy document has many versions.

---

# 4. ESSENTIAL INDEXES

Add indexes on:
- users(username)
- users(country_code)
- clubs(owner_user_id)
- clubs(country_code, city_name)
- player_cards(player_id, season_edition, tier)
- player_cards(owner_user_id)
- player_card_listings(status, listed_price_coin)
- competitions(state, starts_at)
- competition_matches(kickoff_at, match_state)
- national_team_entries(user_id, competition_id)
- wallet_ledger_entries(wallet_id, created_at)
- gift_transactions(receiver_id, created_at)
- match_views(match_id, created_at)
- premium_video_purchases(match_id, created_at)
- integrity_scores(score)

---

# 5. CONFIG TABLES / ENUMS YOU SHOULD EXTERNALIZE

Prefer config tables or strongly centralized enums for:
- competition families
- gift settlement types
- wallet source tags
- service pricing
- stadium level curves
- reward progression tables
- competition calendars
- youth age limits
- rarity multipliers
- card moniker eligibility rules
- gift retention bonus bands
- platform rake percentages
- trading fee percentages
- withdrawal fee percentages

---

# 6. DOCUMENTS AND COMPLIANCE ARTIFACTS TO INCLUDE

Codex should also create document shells/templates for:
- Terms & Conditions
- Privacy Policy
- AML Policy
- Anti-Fraud Policy
- Community Guidelines
- Competition Rules
- Rewards Funded by GTEX Promotional Pools Policy
- FanCoin Terms
- Player Card Marketplace Rules
- Withdrawal Policy
- Refund / Chargeback Policy
- App Store / Play Store compliance disclosures
- Data usage / consent disclosure
- Content moderation and reporting policy
- Fair play / integrity policy

Track acceptance/versioning in the schema above.

---

# 7. APP STORE / PLAY STORE / DESKTOP READINESS NOTES

Prepare schema support for:
- content reports
- moderation actions
- user blocks/mutes
- privacy consent tracking
- age-gating fields if needed
- device/session tracking for fraud prevention
- purchase records and refund states

Cross-platform target surfaces:
- iOS
- Android
- macOS
- Windows
- tablets

Flutter-friendly API design should expose:
- wallet summaries
- club summaries
- competition schedules
- match viewing endpoints
- spectator feed
- legal document acceptance
- market listings
- national team entry/status
- admin policy/config endpoints

---

# 8. CODEx IMPLEMENTATION HINT

Do not build giant god-services.

Prefer:
- policy engine
- competition engine
- wallet engine
- market engine
- player import engine
- national team engine
- media engine
- integrity engine
- admin engine
- story feed engine

Use domain events such as:
- match_completed
- competition_settled
- gift_sent
- reward_granted
- card_listed
- card_sold
- player_imported
- national_entry_confirmed
- video_view_purchased
- withdrawal_requested

---

# 9. DELIVERABLE EXPECTATION

When Codex uses this schema pack, it should return:
- migrations
- models
- services
- seed/config tables
- admin/legal document management
- API contracts
- tests
- data import scripts