
# GTEX MASTER SUPER-MEGA CODEX BUILD PROMPT
Version: Complete Architecture + Product + Compliance Build

Codex, your task is to build the entire GTEX platform based on the following specification.

Build GTEX as a rules‑driven, event‑based platform architecture.
Do NOT hardcode competitions or reward logic.

Core principles:
- template-driven competitions
- centralized wallet routing
- promotional reward pools
- event-driven services
- modular architecture

Platform targets:
iOS, Android, macOS, Windows, tablets.

Recommended stack:
Backend: FastAPI, PostgreSQL, Redis
Frontend: Flutter

Core modules:
policy_engine
competition_engine
calendar_engine
wallet_engine
gift_engine
market_engine
player_import_engine
national_team_engine
media_engine
integrity_engine
story_feed_engine
admin_engine

Currencies:
FanCoin (gifts, competitions, cosmetics)
Coin (market + rewards)

1 Coin = 100 FanCoin equivalent for services.

FanCoin cannot buy player cards.

All GTEX competition rewards are funded by GTEX promotional pools.

Competition templates must define:
competition_type
team_type
age_grade
participants
cup_or_league
reward_pool
viewing_mode
gift_rules
seeding_method

Global competitions include:
GTEX leagues
GTEX champions competitions
GTEX world championship
GTEX world cup
continental tournaments
youth competitions
user hosted cups
queue cups
fast matches

When GTEX World Cup or World Championship is active,
all other GTEX competitions pause.

Youth competitions:
U17
U20
U21 (Europe)

World cups:
U20 World Cup
U17 World Cup

Player database:
100k players initially.
Support CSV/API import and youth prospect generation.

Player cards:
peer-to-peer trading
20% trading fee
users cannot sell back to admin.

Gift system:
30% platform rake.

Stadium system:
5k base capacity
upgrades increase revenue and prestige.

Revenue split:
home club 80%
away club 20%

Integrity engine must detect:
match fixing
gift farming
bot spectators
wash trading

Supporter shares:
fan participation tokens (non‑financial).

Payments:
cards
Apple Pay
Google Pay
regional rails
crypto deposits (converted to fiat)

Legal docs required:
Terms and Conditions
Privacy Policy
AML Policy
Anti‑Fraud Policy
Community Guidelines
Withdrawal Policy
FanCoin Terms
Marketplace Rules
Responsible Play Policy

App store requirements:
privacy disclosure
content moderation
reporting tools
refund policy

Admin dashboard:
competition scheduling
reward pools
player imports
economy monitoring
fraud alerts

Story feed:
giant killer matches
champion clashes
rivalries

Daily engagement:
daily challenges with small FanCoin rewards.

Testing required:
economy simulation
wallet routing
competition lifecycle
gift routing
player import validation

Return:
full repository
migrations
API documentation
deployment guide
admin setup guide
